import FooterComponent from "../../components/User/Footer";

export default function Footer() {
  return <FooterComponent />;
}
