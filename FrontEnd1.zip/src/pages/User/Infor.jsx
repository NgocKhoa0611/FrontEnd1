import InforComponent from "../components/Infor";

const Infor = () => {
    return <InforComponent />;
};

export default Infor;
