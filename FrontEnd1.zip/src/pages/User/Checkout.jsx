import Checkout from "../../components/User/Checkout";  // Import component Checkout

const Category = () => {
  return <Checkout />;  // Render component Checkout
};

export default Category;
