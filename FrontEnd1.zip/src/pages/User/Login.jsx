import LoginComponent from "../../components/User/account/Login";

const Login = () => {
  return <LoginComponent />;
};

export default Login;
