import CartComponent from "../../components/User//Cart";

const Cart = () => {
  return (
    <>
      <CartComponent />
    </>
  );
};

export default Cart;
