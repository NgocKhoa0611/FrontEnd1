import ProductDetailComponent from "../../components/User/ProductDetail";

const ProductDetail = () => {
  return <ProductDetailComponent />;
};

export default ProductDetail;
