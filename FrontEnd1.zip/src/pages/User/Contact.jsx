import ContactComponent from "../../components/User/Contact";

const Contact = () => {
  return <ContactComponent />;
};

export default Contact;
