import AccountComponent from "../../components/User/account/Account";

const Account = () => {
  return <AccountComponent />;
};

export default Account;
