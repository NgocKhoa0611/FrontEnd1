import HeaderComponent from "../../components/User/Header";

export default function Header() {
  return <HeaderComponent />;
}
