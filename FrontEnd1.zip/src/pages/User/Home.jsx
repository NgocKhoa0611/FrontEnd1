import HomeComponent from "../../components/User/Home";

export default function Home() {
  return <HomeComponent />;
}
