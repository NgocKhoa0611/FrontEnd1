import RegisterComponent from "../../components/User//account/Register";

const Register = () => {
  return <RegisterComponent />;
};

export default Register;
