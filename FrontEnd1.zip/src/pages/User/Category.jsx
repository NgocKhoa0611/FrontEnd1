import CategoryComponent from "../../components/User/Category";

const Category = () => {
  return <CategoryComponent />;
};

export default Category;
